﻿Public Class BMI

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim weight As Double = Double.Parse(TextBox1.Text) 'input weight in kg
        Dim height As Double = Double.Parse(TextBox2.Text) 'input height in meters
        Dim age As Integer = Integer.Parse(TextBox5.Text) 'input age in years

        Dim bmi As Double = weight / (height * height) 'calculate BMI
        TextBox3.Text = bmi.ToString("#.##") 'display BMI result to 2 decimal places

        'give health tips according to age
        If age < 18 Then 'for children and teenagers
            If bmi < 18.5 Then
                healthTipsLabel.Text = "You are underweight. Eat a balanced diet and exercise regularly to maintain a healthy weight."
            ElseIf bmi >= 18.5 And bmi <= 24.9 Then
                healthTipsLabel.Text = "You have a healthy weight. Keep up the good work with a balanced diet and regular exercise."
            ElseIf bmi > 24.9 Then
                healthTipsLabel.Text = "You are overweight. Cut down on sugary and fatty foods, and increase your physical activity to lose weight."
            End If
        Else 'for adults
            If bmi < 18.5 Then
                healthTipsLabel.Text = "You are underweight. Eat a balanced diet and exercise regularly to maintain a healthy weight."
            ElseIf bmi >= 18.5 And bmi <= 24.9 Then
                healthTipsLabel.Text = "You have a healthy weight. Keep up the good work with a balanced diet and regular exercise."
            ElseIf bmi > 24.9 And bmi <= 29.9 Then
                healthTipsLabel.Text = "You are overweight. Cut down on sugary and fatty foods, and increase your physical activity to lose weight."
            ElseIf bmi > 29.9 And bmi <= 34.9 Then
                healthTipsLabel.Text = "You are obese (Class 1). Talk to your doctor or a registered dietitian about developing a weight loss plan."
            ElseIf bmi > 34.9 And bmi <= 39.9 Then
                healthTipsLabel.Text = "You are obese (Class 2). Talk to your doctor or a registered dietitian about developing a weight loss plan."
            ElseIf bmi > 39.9 Then
                healthTipsLabel.Text = "You are obese (Class 3). Talk to your doctor or a registered dietitian about developing a weight loss plan."
            End If
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Clear() 'clear weight text box
        TextBox2.Clear() 'clear height text box
        TextBox5.Clear() 'clear age text box
        TextBox3.Text = "" 'clear BMI result label
        healthTipsLabel.Text = "" 'clear health tips label
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

    End Sub
End Class
